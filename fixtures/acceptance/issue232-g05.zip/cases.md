# 실제 확인 사례

각 행은 해당 분기의 기대와 실제 검증 사건을 연결한다. 관찰 상세는 manifest의 같은 사례 ID에서 확인한다.

| 사례 | 캐릭터·공통 항목 | 기대 결과 | 수행 | 시작 파일 | 자동 | 사용자 | 실기기 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| G05-C01 | shared-setup | 15명의 실제 배정과 좌석을 검증한 첫날 밤이며 미배정 후보가 능력을 얻지 않는다. | [G05 절차 0](G05.md) | [G05-start](G05-start.game.json) | 통과 | 미확인 | 미확인 |
| G05-C02 | character-vigormortis | 비고르모르티스의 Setup 보정으로 15인 외지인은 1명, 마을주민은 10명이다. | [G05 절차 0](G05.md) | [G05-start](G05-start.game.json) | 통과 | 미확인 | 미확인 |
| G05-C03 | character-artist, character-philosopher | 철학자가 획득한 화가로 참인 예를 전달하고 획득 출처의 1회 사용을 소진한다. | [G05 절차 13](G05.md) | [G05-day-one](G05-day-one.game.json) | 통과 | 미확인 | 미확인 |
| G05-C04 | character-vigormortis, shared-pending-restore | 12번 독살범을 살해한 후 미완료 중독 선택을 복원해 이웃 마을주민 10번을 중독시킨다. | [G05 절차 27](G05.md) | [G05-vigor-poison-pending](G05-vigor-poison-pending.game.json) | 통과 | 미확인 | 미확인 |
| G05-C05 | character-juggler | 전날 기록한 정답 2개가 정상 곡예사 정보 2로 전달된다. | [G05 절차 32](G05.md) | [G05-vigor-poison-pending](G05-vigor-poison-pending.game.json) | 통과 | 미확인 | 미확인 |
| G05-C06 | character-vigormortis, character-poisoner | 죽은 12번 독살범이 기존 능력 instance로 다음 밤에도 5번을 중독시킨다. | [G05 절차 41](G05.md) | [G05-retained-minion](G05-retained-minion.game.json) | 통과 | 미확인 | 미확인 |
| G05-C07 | character-pitHag, character-noDashii | 노 다시 변경 후 공격 대상을 먼저 고른다. 외지인·하수인을 건너뛴 1번과 10번만 노 다시 중독이다. | [G05 절차 45](G05.md) | [G05-new-demon](G05-new-demon.game.json) | 통과 | 미확인 | 미확인 |
| G05-C08 | character-pitHag | 예측불허의 죽음에서 마귀할멈이 유발한 단계임을 확인하고 사망 없음을 확정한다. 8번은 생존하며 이 사망 판단은 별도로 되돌릴 수 있다. | [G05 절차 47](G05.md) | [G05-arbitrary-deaths-pending](G05-arbitrary-deaths-pending.game.json) | 통과 | 미확인 | 미확인 |
| G05-C09 | character-sage, shared-jinx-recluse-sage | 은둔자가 후보 풀에만 있으면 현자는 실제 살해자 15번이 포함된 정보를 받는다. | [G05 절차 64](G05.md) | [G05-pool-only-sage](G05-pool-only-sage.game.json) | 통과 | 미확인 | 미확인 |
| G05-C10 | character-noDashii | 노 다시가 죽으면 그 출처의 이웃 중독은 사라진다. | [G05 절차 77](G05.md) | [G05-pool-only-sage](G05-pool-only-sage.game.json) | 통과 | 미확인 | 미확인 |
| G05-C11 | shared-end-game | 선 승리가 확정되고 이후 밤 진행을 거부한다. | [G05 절차 78](G05.md) | [G05-pool-only-sage](G05-pool-only-sage.game.json) | 통과 | 미확인 | 미확인 |
